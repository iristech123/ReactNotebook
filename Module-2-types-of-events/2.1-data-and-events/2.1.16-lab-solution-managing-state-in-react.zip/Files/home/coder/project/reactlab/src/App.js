import React from "react";
import Fruits from "./Fruits.js";
import FruitsCounter from "./FruitsCounter.js";

function App() {

  const [fruits] = React.useState([
      {fruitName: 'apple', id: 1},
      {fruitName: 'apple', id: 2},
      {fruitName: 'plum', id: 3},
  ]);

  return (
    <div className="App">
      <h1>Where should the state go?</h1>
      {/* The first step of this task is to move the state from the Fruits  */}
      <Fruits fruits={fruits} /> 
      <FruitsCounter fruits={fruits} />
    </div>
  );
}

export default App;
