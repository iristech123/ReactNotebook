import React, { useState, useRef } from "react";
import "./App.css";

function App() {
  const inputRef = useRef(null); // Reference to input field
  const resultRef = useRef(null); // Reference to result display
  const [result, setResult] = useState(0); // State for the result

  // Function to handle addition
  const add = () => {
    setResult((prev) => prev + Number(inputRef.current.value));
  };

  // Function to handle subtraction
  const subtract = () => {
    setResult((prev) => prev - Number(inputRef.current.value));
  };

  // Function to handle multiplication
  const multiply = () => {
    setResult((prev) => prev * Number(inputRef.current.value));
  };

  // Function to handle division
  const divide = () => {
    setResult((prev) => prev / Number(inputRef.current.value));
  };

  // Function to reset input field
  const resetInput = () => {
    inputRef.current.value = "";
  };

  // Function to reset the result
  const resetResult = () => {
    setResult(0);
  };

  return (
    <div className="App">
      <h1>Simple Calculator</h1>
      <div ref={resultRef}>Result: {result}</div>
      <input type="number" ref={inputRef} placeholder="Enter a number" />
      <div>
        <button onClick={add}>Add</button>
        <button onClick={subtract}>Subtract</button>
        <button onClick={multiply}>Multiply</button>
        <button onClick={divide}>Divide</button>
        <button onClick={resetInput}>Reset Input</button>
        <button onClick={resetResult}>Reset Result</button>
      </div>
    </div>
  );
}

export default App;
